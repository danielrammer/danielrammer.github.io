
SobGob is a one on one staring duel. A player has to push balls towards the opponent by just staring at them.
If both gaze on the same object nothing happens. This mind game is about finding the proper tactics against your adversary.
Locking at powerups may disturb your opponent’s view – but it also could affect you screen.
It’s a network application which utilizes Tobii eye trackers.


Required hardware:
	- 2 PCs (or notebooks) in the same network.
		o Playing online is possible but, as usual, comes with latency (max. 20 concurrent players)
	- 2 Tobii eye trackers, one connected to each machine.

	
Play Game:
	- Start sobgob.exe
	- Click "Play!" In der SobGob Configuration dialog
		o Full screen mode recommended (uncheck Windowed if checked)
	- Click "Play"
	- AUTO
		o Click "AUTO" on the first machine – becomes a server automatically
		o Wait for "waiting for second player" message
		o Click "AUTO" on the second PC – it starts looking for a server within the network and connects to it.
		
	- MANUAL (only use if AUTO fails or if multiple games are played in the same network)
		o After clicking "MANUAL", a network menu appears on the top left corner of the screen
		o On the first PC – click "LAN Host"
		o On the second PC – enter the first PCs IP-Address and click "LAN Client"
		
	- MANUAL (Online)
		o Start in "MANUAL" mode
		o Click "Enable Match Maker"
		o PC #1: Enter room name or leave "default" and click "Create Internet Match"
			> Wait for "waiting for second player" message
		o PC #2: Click "Find Internet Match"
			> Click "Join Match: matchname"
			> Play SobGob online :)
			
Enjoy playing this experimental virtual staring duel!
